"""Run Registry CLI module."""
